﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace work11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen grayPen = new Pen(Color.Gray, 1);
            g.DrawLine(grayPen, new Point(textBox1.Location.X + 16, textBox1.Location.Y), 
                                                    new Point(textBox2.Location.X + 16, textBox2.Location.Y));
            g.DrawLine(grayPen, new Point(textBox1.Location.X + 16, textBox1.Location.Y),
                                                    new Point(textBox3.Location.X + 16, textBox2.Location.Y));

            g.DrawLine(grayPen, new Point(textBox2.Location.X + 16, textBox2.Location.Y),
                                                    new Point(textBox4.Location.X + 16, textBox4.Location.Y));
            g.DrawLine(grayPen, new Point(textBox2.Location.X + 16, textBox2.Location.Y),
                                                    new Point(textBox5.Location.X + 16, textBox5.Location.Y));

            g.DrawLine(grayPen, new Point(textBox3.Location.X + 16, textBox3.Location.Y),
                                                    new Point(textBox6.Location.X + 16, textBox6.Location.Y));
            g.DrawLine(grayPen, new Point(textBox3.Location.X + 16, textBox3.Location.Y),
                                                    new Point(textBox7.Location.X + 16, textBox7.Location.Y));

            g.DrawLine(grayPen, new Point(textBox4.Location.X + 16, textBox4.Location.Y),
                                                    new Point(textBox8.Location.X + 16, textBox8.Location.Y));
            g.DrawLine(grayPen, new Point(textBox4.Location.X + 16, textBox4.Location.Y),
                                                    new Point(textBox9.Location.X + 16, textBox9.Location.Y));

            g.DrawLine(grayPen, new Point(textBox5.Location.X +    16, textBox5.Location.Y),
                                                    new Point(textBox10.Location.X + 16, textBox10.Location.Y));
            g.DrawLine(grayPen, new Point(textBox5.Location.X +    16, textBox5.Location.Y),
                                                    new Point(textBox11.Location.X + 16, textBox11.Location.Y));

            g.DrawLine(grayPen, new Point(textBox6.Location.X +    16, textBox6.Location.Y),
                                                    new Point(textBox12.Location.X + 16, textBox12.Location.Y));
            g.DrawLine(grayPen, new Point(textBox6.Location.X +    16, textBox6.Location.Y),
                                                    new Point(textBox13.Location.X + 16, textBox13.Location.Y));

            g.DrawLine(grayPen, new Point(textBox7.Location.X +    16, textBox7.Location.Y),
                                                    new Point(textBox14.Location.X + 16, textBox14.Location.Y));
            g.DrawLine(grayPen, new Point(textBox7.Location.X +    16, textBox7.Location.Y),
                                                    new Point(textBox15.Location.X + 16, textBox15.Location.Y));

        }

        List<int> heap = new List<int>();
        TextBox[] arr = new TextBox[15];
        int c;

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Paint += new PaintEventHandler(Form1_Paint);

            arr[0] = textBox1;
            arr[1] = textBox2;
            arr[2] = textBox3;
            arr[3] = textBox4;
            arr[4] = textBox5;
            arr[5] = textBox6;
            arr[6] = textBox7;
            arr[7] = textBox8;
            arr[8] = textBox9;
            arr[9] = textBox10;
            arr[10] = textBox11;
            arr[11] = textBox12;
            arr[12] = textBox13;
            arr[13] = textBox14;
            arr[14] = textBox15;

            c = 0;

        }

        public void printHeap()
        {
            int i ;
            for ( i = 0; i < 15; i++)
            {
                arr[i].Text = "";
            }
            for (i = 0; i < heap.Count; i++)
            {
                arr[i].Text = ""+heap[i];
            }
        }

        public void addheapSort(int self)
        {
            int parentL;
            int parentR;
            if (heap.Count == 2)
            {
                if (heap[1] > heap[0])
                {
                    int tmp = heap[1];
                    heap[1] = heap[0];
                    heap[0] = tmp;
                }
                return;
            }

            while (self >= 1)
            {
                parentL = self /2;
                parentR = self /2  - 1;

                if (self%2 !=0 && heap[self] > heap[parentL])
                {
                    int tmp = heap[self];
                    heap[self] = heap[parentL];
                    heap[parentL] = tmp;
                    self = heap.IndexOf(tmp);
                }
                else if (self % 2 == 0 && heap[self] > heap[parentR])
                {
                    int tmp = heap[self];
                    heap[self] = heap[parentR];
                    heap[parentR] = tmp;
                    self = heap.IndexOf(tmp);
                }
                else
                {
                    break;
                }
            }
        }

        public void removeheapSort()
        {
            int childrenL;
            int childrenR;
            int a = 0;
            if (heap.Count == 2)
            {
                if (heap[1] > heap[0])
                {
                    int tmp = heap[1];
                    heap[1] = heap[0];
                    heap[0] = tmp;
                }
                return;
            }

            for (int self=0; self <= (heap.Count/2-1); self++)
            {
                while (self <= (heap.Count / 2 - 1))
                {
                    childrenL = self * 2 + 1;
                    childrenR = self * 2 + 2;
                    if(childrenR >= heap.Count && heap[self] < heap[childrenL])
                    {
                        int tmp = heap[self];
                        heap[self] = heap[childrenL];
                        heap[childrenL] = tmp;

                        self = heap.IndexOf(tmp);
                    }
                    else if (childrenR >= heap.Count && heap[self] > heap[childrenL])
                    {
                        break;
                    }
                    else if (heap[childrenL] > heap[childrenR] && heap[self] < heap[childrenL])
                    {
                        int tmp = heap[self];
                        heap[self] = heap[childrenL];
                        heap[childrenL] = tmp;

                        self = heap.IndexOf(tmp);
                    }
                    else if (heap[childrenL] < heap[childrenR] && heap[self] < heap[childrenR])
                    {
                        int tmp = heap[self];
                        heap[self] = heap[childrenR];
                        heap[childrenR] = tmp;

                        self = heap.IndexOf(tmp);
                    }
                    else
                    {
                        break;
                    }
                    a++;
                }
            }
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (heap.Count < 15)
            {
                heap.Add(Convert.ToInt32(textBox16.Text));
            }

            addheapSort(heap.Count-1);

            printHeap();
            textBox16.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {

            textBox17.Text = arr[0].Text;
            heap[0] = heap[heap.Count - 1];
            heap.RemoveAt(heap.Count - 1);
            removeheapSort();

            printHeap();
        }
    }
}
