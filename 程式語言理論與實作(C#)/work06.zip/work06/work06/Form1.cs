﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace work06
{
	public partial class Form1 : Form
	{
		abstract class Component
		{
			protected string name;
			public abstract double area();
			public abstract string show();
			public string getName()
			{ return name; }
		}
		abstract class Shape : Component { }

	    class Picture : Component
		{
			private List<Component> coms = new List<Component>();
			public Picture(string n)
			{
				this.name = n;
			}
			public void addComponent(Component c)
			{
				coms.Add(c);
			}
			public override double area()
			{
				double total = 0.0;
				for (int i = 0; i < coms.Count; i++)
				{
					total = total + coms[i].area();
				}
				return total;
			}

			public override string show()
			{
				string str = "{Picture " + this.name + ":";

				for (int i = 0; i < coms.Count; i++)
				{
					str = str + "" + coms[i].show();
				}
				str = str + "} ";
				return str;
			}

		}

		class Rectangle : Shape
		{
			private double length;
			private double width;
			public Rectangle(string n, double l, double w)
			{
				this.name = n;
				this.length = l;
				this.width = w;
			}
			public override double area()
			{
				return this.length * this.width;
			}
			public override string show()
			{
				return " Rectangle " + this.name + "(" + this.length + "," + this.width + ") ";
			}
		}
		class Triangle : Shape
		{
			private double tbase;
			private double height;
			public Triangle(string n, double tbase, double h)
			{
				this.name = n;
				this.tbase = tbase;
				this.height = h;
			}
			public override double area()
			{
				return 0.5 * this.tbase * this.height;
			}
			public override string show()
			{
				return " Triangle " + this.name + "(" + this.tbase + "," + this.height + ") ";
			}
		}
		class Circle : Shape
		{
			private double radius;
			public Circle(string n, double r)
			{
				this.name = n;
				this.radius = r;
			}
			public override double area()
			{
				return this.radius * this.radius * Math.PI;
			}
			public override string show()
			{
				return " Circle " + this.name + "(" + this.radius + ") ";
			}
		}


		public Form1()
		{
			InitializeComponent();
		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{
            try
            {
				Form2 f2 = new Form2();
				f2.ShowDialog();
				string newName;
				string contain;
				string n;
				if (f2.DialogResult == DialogResult.OK)
				{
					 n = f2.getData(out newName);
					Picture p = new Picture(newName);
					bool found = false;
					for (int i = 0; i < allpicture.Count; i++)
					{
						if (allpicture[i].getName() == n)
						{
							found = true;
							break;
						}
					}
					if(!found) throw new Exception("不存在的Picture容器:" + n);
					else allpicture.Add(p);
					
					for (int i = 0; i < allpicture.Count; i++)
					{
						if (allpicture[i].getName() == n)
						{
							allpicture[i].addComponent(p);
						}
					}
					textBox1.Text = allpicture[0].show();
				}
			}
            catch (Exception ex)
            {
				MessageBox.Show(ex.Message, "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

		}

		Picture graph = new Picture("Graph");
		List<Picture> allpicture = new List<Picture>();
		private void Form1_Load(object sender, EventArgs e)
		{
			textBox1.ReadOnly = true;
			textBox1.Text = "{Picture Graph:}";
			allpicture.Add(graph);
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
		}

		private void button2_Click(object sender, EventArgs e)
		{
            try
            {
				Form3 f3 = new Form3();
				f3.ShowDialog();
				string newName;
				double length;
				double width;
				if (f3.DialogResult == DialogResult.OK)
				{
					string n = f3.getData(out newName, out length, out width);
					Rectangle p = new Rectangle(newName, length, width);
					for (int i = 0; i < allpicture.Count; i++)
					{
						if (allpicture[i].getName() == n)
						{
							allpicture[i].addComponent(p);
						}
					}
					textBox1.Text = allpicture[0].show();
				}
			}
            catch (Exception ex)
            {
				MessageBox.Show("輸入字串格是不正確", "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}


		}

		private void button3_Click(object sender, EventArgs e)
		{
            try
            {
				Form4 f4 = new Form4();
				f4.ShowDialog();
				string newName;
				double tbase;
				double height;
				if (f4.DialogResult == DialogResult.OK)
				{
					string n = f4.getData(out newName, out tbase, out height);
					Triangle p = new Triangle(newName, tbase, height);
					for (int i = 0; i < allpicture.Count; i++)
					{
						if (allpicture[i].getName() == n)
						{
							allpicture[i].addComponent(p);
						}
					}
					textBox1.Text = allpicture[0].show();
				}
			}
            catch (Exception ex)
            {
				MessageBox.Show("輸入字串格是不正確", "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

		}

		private void button4_Click(object sender, EventArgs e)
		{
            try
            {
				Form5 f5 = new Form5();
				f5.ShowDialog();
				string newName;
				double r;
				if (f5.DialogResult == DialogResult.OK)
				{
					string n = f5.getData(out newName, out r);
					Circle p = new Circle(newName, r);
					for (int i = 0; i < allpicture.Count; i++)
					{
						if (allpicture[i].getName() == n)
						{
							allpicture[i].addComponent(p);
						}
					}
					textBox1.Text = allpicture[0].show();
				}
			}
            catch (Exception ex)
            {
				MessageBox.Show("輸入字串格是不正確", "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

		}

        private void button5_Click(object sender, EventArgs e)
        {
			textBox2.Text = "" + allpicture[0].area();
		}
    }
}
