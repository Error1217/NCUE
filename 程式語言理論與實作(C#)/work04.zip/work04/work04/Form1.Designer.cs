﻿
namespace work04
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(73, 51);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(55, 22);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(134, 51);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(55, 22);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(195, 51);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(55, 22);
            this.textBox3.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(256, 51);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(55, 22);
            this.textBox4.TabIndex = 3;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(317, 51);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(55, 22);
            this.textBox5.TabIndex = 4;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(378, 51);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(55, 22);
            this.textBox6.TabIndex = 5;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(73, 79);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(55, 22);
            this.textBox7.TabIndex = 11;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(134, 79);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(55, 22);
            this.textBox8.TabIndex = 10;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(195, 79);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(55, 22);
            this.textBox9.TabIndex = 9;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(258, 79);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(55, 22);
            this.textBox10.TabIndex = 8;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(317, 79);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(55, 22);
            this.textBox11.TabIndex = 7;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(378, 79);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(55, 22);
            this.textBox12.TabIndex = 6;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(102, 256);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(75, 22);
            this.textBox37.TabIndex = 36;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 266);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 37;
            this.label1.Text = "最大得分";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(208, 256);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 23);
            this.button1.TabIndex = 38;
            this.button1.Text = "產生最佳路徑";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(319, 256);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 23);
            this.button2.TabIndex = 39;
            this.button2.Text = "存檔輸出";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(420, 256);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 23);
            this.button3.TabIndex = 40;
            this.button3.Text = "讀檔輸入";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 41;
            this.label2.Text = "入口";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(441, 201);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 42;
            this.label3.Text = "出口";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(73, 107);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(55, 22);
            this.textBox13.TabIndex = 48;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(134, 107);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(55, 22);
            this.textBox14.TabIndex = 47;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(195, 107);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(55, 22);
            this.textBox15.TabIndex = 46;
            this.textBox15.TextChanged += new System.EventHandler(this.textBox15_TextChanged);
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(258, 107);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(55, 22);
            this.textBox16.TabIndex = 45;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(317, 107);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(55, 22);
            this.textBox17.TabIndex = 44;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(378, 107);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(55, 22);
            this.textBox18.TabIndex = 43;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(73, 135);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(55, 22);
            this.textBox19.TabIndex = 54;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(134, 135);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(55, 22);
            this.textBox20.TabIndex = 53;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(195, 135);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(55, 22);
            this.textBox21.TabIndex = 52;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(258, 135);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(55, 22);
            this.textBox22.TabIndex = 51;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(319, 135);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(55, 22);
            this.textBox23.TabIndex = 50;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(378, 135);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(55, 22);
            this.textBox24.TabIndex = 49;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(73, 163);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(55, 22);
            this.textBox25.TabIndex = 60;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(134, 163);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(55, 22);
            this.textBox26.TabIndex = 59;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(195, 163);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(55, 22);
            this.textBox27.TabIndex = 58;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(258, 163);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(55, 22);
            this.textBox28.TabIndex = 57;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(317, 163);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(55, 22);
            this.textBox29.TabIndex = 56;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(378, 163);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(55, 22);
            this.textBox30.TabIndex = 55;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(73, 191);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(55, 22);
            this.textBox31.TabIndex = 66;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(134, 191);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(55, 22);
            this.textBox32.TabIndex = 65;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(195, 191);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(55, 22);
            this.textBox33.TabIndex = 64;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(258, 191);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(55, 22);
            this.textBox34.TabIndex = 63;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(319, 191);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(55, 22);
            this.textBox35.TabIndex = 62;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(380, 191);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(55, 22);
            this.textBox36.TabIndex = 61;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 317);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

