﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;


namespace work05
{
	public partial class Form1 : Form
	{
		bool levelInput = true;
		bool dataInput = false;
		bool compute = false;
		int level, row, column;
		int[,] matrix = new int[10, 10];

		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				if (dataInput)
				{
					int input = Convert.ToInt32(textBox2.Text);
					if (column==level-1)
					{
						row++;
						column = 0;
						textBox4.Text = textBox4.Text + "\r\n";
					}
					else
					{
						column++;
						if (row==level-1&&column==level-1)
						{
							compute = true;
							dataInput = false;
						}
					}
					textBox4.Text = textBox4.Text + textBox2.Text + " ";
					matrix[row, column] = input;
					textBox2.Text = "";

				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{

			openFileDialog1.Filter = "二元檔案(*.dat)|*.dat";
			if (openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open);
				BinaryReader br = new BinaryReader(fs);
				
				while (br.PeekChar() >= 0)
				{
					textBox1.Text = br.ReadInt32() + "";
					level = Convert.ToInt32(textBox1.Text);
					for (int col = 0; col < level; col++)
					{
						for (int row = 0; row < level; row++)
						{
							matrix[row, col] = br.ReadInt32();
							textBox4.Text += matrix[row, col] + " ";
						}
						textBox4.Text += "\r\n";
					}
				}
				br.Close();
				fs.Close();
			}

		}

		private void button4_Click(object sender, EventArgs e)
		{
			saveFileDialog1.Filter = "二元檔案(*.dat)|*.dat";
			if (saveFileDialog1.ShowDialog() == DialogResult.OK)
			{
				FileStream fs = new FileStream(saveFileDialog1.FileName, FileMode.Create);
				BinaryWriter bw = new BinaryWriter(fs);
				level = Convert.ToInt32(textBox1.Text);
				bw.Write(level);
				for (int col = 0; col < level; col++)
				{
					for (int row = 0; row < level; row++)
					{
						bw.Write(matrix[row,col]);
					}
				}
				bw.Flush();
				bw.Close();
				fs.Close();
			}
		}

		private void button5_Click(object sender, EventArgs e)
		{
			textBox1.Text = "";
			textBox2.Text = "";
			textBox3.Text = "";
			textBox4.Text = "";
		}

		int det(int[,] arr, int n)
		{
			int[,] change = new int[level, level];
			int result = 0;
			int pn;
			if (n==1)
			{
				return arr[0, 0];
			}
			if (n >= 1)
			{
				for (int i = 0; i < n; i++)
				{
					remain_copy(i, arr,ref change, n);

					if (i % 2 == 0)
					{
						pn = 1;
					}
					else
					{
						pn = -1;
					}
					
					result = result + pn * arr[i, 0] * det(change, n-1);

				}
			}
			return result;
		}

		void remain_copy(int i, int[,] arr,ref int[,]  change ,int n)
		{
			int k=0;
			for (int p = 0; p < n; p++)
			{
				if (p == i)
					continue;
				for (int j = 1; j < n; j++)
				{
					change[k, j - 1] = arr[p, j];
				}
				k++;
			}
		}

		private void button6_Click(object sender, EventArgs e)
		{
			textBox3.Text = det(matrix, level) + "";
		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{

		}

		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				if (levelInput)
				{
					level = Convert.ToInt32(textBox1.Text);
					if (level>10)
					{
						throw new Exception("矩陣階數超過10");
					}
					else
					{
						row = 0;
						column = -1;
						dataInput = true;
						levelInput = false;
						textBox2.Text = "";
						textBox3.Text = "";
						textBox4.Text = "";
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
	}
}
