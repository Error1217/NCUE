﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace work12
{
    public partial class Form1 : Form
    {
        int[,] initial = new int[10, 10];
        int[,] shortest = new int[10, 10];

        TextBox[,] cost = new TextBox[10, 10];

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox22.ReadOnly = true;
            textBox21.ReadOnly = true;
            this.Paint += new PaintEventHandler(Form1_Paint);
            //
            cost[0, 1] = textBox1;
            cost[0, 2] = textBox2;
            cost[0, 3] = textBox3;
            //
            cost[1, 0] = textBox1;
            cost[1, 3] = textBox4;
            cost[1, 4] = textBox5;
            //
            cost[2, 0] = textBox2;
            cost[2, 3] = textBox6;
            cost[2, 5] = textBox8;
            //
            cost[3, 0] = textBox3;
            cost[3, 1] = textBox4;
            cost[3, 2] = textBox6;
            cost[3, 4] = textBox7;
            cost[3, 5] = textBox9;
            cost[3, 6] = textBox10;
            //
            cost[4, 1] = textBox5;
            cost[4, 3] = textBox7;
            cost[4, 6] = textBox11;
            //
            cost[5,2] = textBox8;
            cost[5,3] = textBox9;
            cost[5,6] = textBox12;
            cost[5,7] = textBox13;
            cost[5,8] = textBox14;
            //
            cost[6,3] = textBox10;
            cost[6,4] = textBox11;
            cost[6,5] = textBox12;
            cost[6,8] = textBox15;
            cost[6,9] = textBox16;
            //
            cost[7,5] = textBox13;
            cost[7,8] = textBox17;
            //
            cost[8,5] = textBox14;
            cost[8,6] = textBox15;
            cost[8,7] = textBox17;
            cost[8,9] = textBox18;
            //
            cost[9,6] = textBox16;
            cost[9,8] = textBox18;

            textBox1.Text = "8";
            textBox2.Text = "3";
            textBox3.Text = "12";
            textBox4.Text = "23";
            textBox5.Text = "19";
            textBox6.Text = "5";
            textBox7.Text = "2";
            textBox8.Text = "39";
            textBox9.Text = "32";
            textBox10.Text = "16";
            textBox11.Text = "7";
            textBox12.Text = "19";
            textBox13.Text = "17";
            textBox14.Text = "6";
            textBox15.Text = "11";
            textBox16.Text = "2";
            textBox17.Text = "25";
            textBox18.Text = "10";
        }

        void Form1_Paint(object semder, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen grayPen = new Pen(Color.Gray, 1);
            g.DrawLine(grayPen, new Point(label1.Location.X+5, label1.Location.Y),
                                                    new Point(label2.Location.X+5, label2.Location.Y));
            g.DrawLine(grayPen, new Point(label3.Location.X + 5, label3.Location.Y),
                                                    new Point(label4.Location.X + 5, label4.Location.Y));
            g.DrawLine(grayPen, new Point(label4.Location.X + 5, label4.Location.Y),
                                                    new Point(label5.Location.X + 5, label5.Location.Y));
            g.DrawLine(grayPen, new Point(label6.Location.X + 5, label6.Location.Y),
                                                    new Point(label7.Location.X + 5, label7.Location.Y));
            g.DrawLine(grayPen, new Point(label8.Location.X + 5, label8.Location.Y),
                                                    new Point(label9.Location.X + 5, label9.Location.Y));
            g.DrawLine(grayPen, new Point(label9.Location.X + 5, label9.Location.Y),
                                                    new Point(label10.Location.X + 5, label10.Location.Y));

            g.DrawLine(grayPen, new Point(label1.Location.X + 5, label1.Location.Y+5),
                                                    new Point(label3.Location.X + 5, label3.Location.Y+5));
            g.DrawLine(grayPen, new Point(label1.Location.X + 5, label1.Location.Y + 5),
                                                   new Point(label4.Location.X + 5, label4.Location.Y + 5));
            g.DrawLine(grayPen, new Point(label2.Location.X + 5, label2.Location.Y + 5),
                                                   new Point(label4.Location.X + 5, label4.Location.Y + 5));
            g.DrawLine(grayPen, new Point(label2.Location.X + 5, label2.Location.Y + 5),
                                                   new Point(label5.Location.X + 5, label5.Location.Y + 5));
            g.DrawLine(grayPen, new Point(label3.Location.X + 5, label3.Location.Y + 5),
                                                   new Point(label6.Location.X + 5, label6.Location.Y + 5));
            g.DrawLine(grayPen, new Point(label4.Location.X + 5, label4.Location.Y + 5),
                                                   new Point(label6.Location.X + 5, label6.Location.Y + 5));
            g.DrawLine(grayPen, new Point(label4.Location.X + 5, label4.Location.Y + 5),
                                                   new Point(label7.Location.X + 5, label7.Location.Y + 5));
            g.DrawLine(grayPen, new Point(label5.Location.X + 5, label5.Location.Y + 5),
                                                   new Point(label7.Location.X + 5, label7.Location.Y + 5));
            g.DrawLine(grayPen, new Point(label6.Location.X + 5, label6.Location.Y + 5),
                                                   new Point(label8.Location.X + 5, label8.Location.Y + 5));
            g.DrawLine(grayPen, new Point(label6.Location.X + 5, label6.Location.Y + 5),
                                                   new Point(label9.Location.X + 5, label9.Location.Y + 5));
            g.DrawLine(grayPen, new Point(label7.Location.X + 5, label7.Location.Y + 5),
                                                    new Point(label9.Location.X + 5, label9.Location.Y + 5));
            g.DrawLine(grayPen, new Point(label7.Location.X + 5, label7.Location.Y + 5),
                                                    new Point(label10.Location.X + 5, label10.Location.Y + 5));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string start = textBox19.Text;
            string end = textBox20.Text;
            int s = 0;
            int ee = 0;
            bool[] tmp = new bool [10];
            int[,] pre = new int [10, 10];

            //
            if (start == "A") s = 0;
            if (start == "B") s = 1;
            if (start == "C") s = 2;
            if (start == "D") s = 3;
            if (start == "E") s = 4;
            if (start == "F") s = 5;
            if (start == "G") s = 6;
            if (start == "H") s = 7;
            if (start == "I") s = 8;
            if (start == "J") s = 9;

            if (end == "A") ee = 0;
            if (end == "B") ee = 1;
            if (end == "C") ee = 2;
            if (end == "D") ee = 3;
            if (end == "E") ee = 4;
            if (end == "F") ee = 5;
            if (end == "G") ee = 6;
            if (end == "H") ee = 7;
            if (end == "I") ee = 8;
            if (end == "J") ee = 9;

            if (ee == 0) end = "A";
            if (ee == 1) end = "B";
            if (ee == 2) end = "C";
            if (ee == 3) end = "D";
            if (ee == 4) end = "E";
            if (ee == 5) end = "F";
            if (ee == 6) end = "G";
            if (ee == 7) end = "H";
            if (ee == 8) end = "I";
            if (ee == 9) end = "J";



            for (int row = 0; row < 10; row++)
            {
                tmp[row] = false;
                for (int col = 0; col < 10; col++)
                {
                    pre[row, col] = -1;
                    shortest[row, col] = 10000;
                    if (cost[row, col] != null)
                    {
                        initial[row, col] = Convert.ToInt32(cost[row, col].Text);
                    }
                    else
                    {
                        initial[row, col] = 10000;
                    }
                    if (s == col)
                    {
                        shortest[row, col] = -2;
                        pre[row, col] = -2;
                    }
                }
            }
            int small = 10000;
            int small_index = -1;
            //
            for (int col = 0; col < 10; col++)
            {
                if (shortest[0, col] == -2) continue;

                shortest[0, col] = initial[s, col];
                if(shortest[0, col] == 10000) pre[0, col] = -1;
                else pre[0, col] = s;

                if(shortest[0, col] < small)
                {
                    small = shortest[0, col];
                    small_index = col;
                }
            }
            tmp[small_index] = true;
            //
            for (int row = 1; row < 10; row++)
            {
                for (int col = 0; col < 10; col++)
                {
                    //
                    if (tmp[col] || s == col) continue;

                    shortest[row, col] = Math.Min(shortest[row-1, col], small + initial[small_index, col]);
                    if(shortest[row - 1, col] > small + initial[small_index, col])
                    {
                        pre[row, col] = small_index;
                    }
                    else
                    {
                        pre[row, col] = pre[row - 1, col];
                    }
                }
                small = 10000;
                for (int col = 0; col < 10; col++)
                {
                    if (shortest[row, col] == -2) continue;

                    if (shortest[row, col] < small)
                    {
                        small = shortest[row, col];
                        small_index = col;
                    }
                }
                tmp[small_index] = true;
            }
            //
            for (int row = 8; row >= 0; row--)
            {
                if (shortest[row, ee] != 10000)
                {
                    textBox21.Text = "" + shortest[row, ee];
                    break;
                }
            }
            textBox22.Text = "";
            string p = "";
            bool b = false;
            for (int row = 8; row >= 0; row--)
            {
                if (s == small_index)
                {
                    break;
                }

                if (pre[row, ee] != -1)
                {

                    if (pre[row, ee] == 0) p = "A";
                    if (pre[row, ee] == 1) p = "B";
                    if (pre[row, ee] == 2) p = "C";
                    if (pre[row, ee] == 3) p = "D";
                    if (pre[row, ee] == 4) p = "E";
                    if (pre[row, ee] == 5) p = "F";
                    if (pre[row, ee] == 6) p = "G";
                    if (pre[row, ee] == 7) p = "H";
                    if (pre[row, ee] == 8) p = "I";
                    if (pre[row, ee] == 9) p = "J";

                    textBox22.Text =   p + " -> " + textBox22.Text;
                    ee = pre[row, ee];
                }
            }

            textBox22.Text = textBox22.Text + end;

        }
    }
}
