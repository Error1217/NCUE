﻿
namespace work07
{
	partial class Form1
	{
		/// <summary>
		/// 設計工具所需的變數。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 清除任何使用中的資源。
		/// </summary>
		/// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 設計工具產生的程式碼

		/// <summary>
		/// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
		/// 這個方法的內容。
		/// </summary>
		private void InitializeComponent()
		{
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.textBox9 = new System.Windows.Forms.TextBox();
			this.textBox10 = new System.Windows.Forms.TextBox();
			this.textBox11 = new System.Windows.Forms.TextBox();
			this.textBox12 = new System.Windows.Forms.TextBox();
			this.textBox13 = new System.Windows.Forms.TextBox();
			this.textBox14 = new System.Windows.Forms.TextBox();
			this.textBox15 = new System.Windows.Forms.TextBox();
			this.textBox16 = new System.Windows.Forms.TextBox();
			this.textBox17 = new System.Windows.Forms.TextBox();
			this.textBox18 = new System.Windows.Forms.TextBox();
			this.textBox19 = new System.Windows.Forms.TextBox();
			this.textBox20 = new System.Windows.Forms.TextBox();
			this.textBox21 = new System.Windows.Forms.TextBox();
			this.textBox22 = new System.Windows.Forms.TextBox();
			this.textBox23 = new System.Windows.Forms.TextBox();
			this.textBox24 = new System.Windows.Forms.TextBox();
			this.textBox25 = new System.Windows.Forms.TextBox();
			this.textBox26 = new System.Windows.Forms.TextBox();
			this.textBox27 = new System.Windows.Forms.TextBox();
			this.textBox28 = new System.Windows.Forms.TextBox();
			this.textBox29 = new System.Windows.Forms.TextBox();
			this.textBox30 = new System.Windows.Forms.TextBox();
			this.textBox31 = new System.Windows.Forms.TextBox();
			this.textBox32 = new System.Windows.Forms.TextBox();
			this.textBox33 = new System.Windows.Forms.TextBox();
			this.textBox34 = new System.Windows.Forms.TextBox();
			this.textBox35 = new System.Windows.Forms.TextBox();
			this.textBox36 = new System.Windows.Forms.TextBox();
			this.textBox37 = new System.Windows.Forms.TextBox();
			this.textBox38 = new System.Windows.Forms.TextBox();
			this.textBox39 = new System.Windows.Forms.TextBox();
			this.textBox40 = new System.Windows.Forms.TextBox();
			this.textBox41 = new System.Windows.Forms.TextBox();
			this.textBox42 = new System.Windows.Forms.TextBox();
			this.textBox43 = new System.Windows.Forms.TextBox();
			this.textBox44 = new System.Windows.Forms.TextBox();
			this.textBox45 = new System.Windows.Forms.TextBox();
			this.textBox46 = new System.Windows.Forms.TextBox();
			this.textBox47 = new System.Windows.Forms.TextBox();
			this.textBox48 = new System.Windows.Forms.TextBox();
			this.textBox49 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(74, 37);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(24, 22);
			this.textBox1.TabIndex = 0;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(104, 37);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(24, 22);
			this.textBox2.TabIndex = 1;
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(134, 37);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(24, 22);
			this.textBox3.TabIndex = 2;
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(164, 37);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(24, 22);
			this.textBox4.TabIndex = 3;
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(194, 37);
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(24, 22);
			this.textBox5.TabIndex = 4;
			// 
			// textBox6
			// 
			this.textBox6.Location = new System.Drawing.Point(224, 37);
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(24, 22);
			this.textBox6.TabIndex = 5;
			// 
			// textBox7
			// 
			this.textBox7.Location = new System.Drawing.Point(254, 37);
			this.textBox7.Name = "textBox7";
			this.textBox7.Size = new System.Drawing.Size(24, 22);
			this.textBox7.TabIndex = 6;
			// 
			// textBox8
			// 
			this.textBox8.Location = new System.Drawing.Point(74, 65);
			this.textBox8.Name = "textBox8";
			this.textBox8.Size = new System.Drawing.Size(24, 22);
			this.textBox8.TabIndex = 7;
			// 
			// textBox9
			// 
			this.textBox9.Location = new System.Drawing.Point(104, 65);
			this.textBox9.Name = "textBox9";
			this.textBox9.Size = new System.Drawing.Size(24, 22);
			this.textBox9.TabIndex = 8;
			// 
			// textBox10
			// 
			this.textBox10.Location = new System.Drawing.Point(134, 65);
			this.textBox10.Name = "textBox10";
			this.textBox10.Size = new System.Drawing.Size(24, 22);
			this.textBox10.TabIndex = 9;
			// 
			// textBox11
			// 
			this.textBox11.Location = new System.Drawing.Point(164, 65);
			this.textBox11.Name = "textBox11";
			this.textBox11.Size = new System.Drawing.Size(24, 22);
			this.textBox11.TabIndex = 10;
			// 
			// textBox12
			// 
			this.textBox12.Location = new System.Drawing.Point(194, 65);
			this.textBox12.Name = "textBox12";
			this.textBox12.Size = new System.Drawing.Size(24, 22);
			this.textBox12.TabIndex = 11;
			// 
			// textBox13
			// 
			this.textBox13.Location = new System.Drawing.Point(224, 65);
			this.textBox13.Name = "textBox13";
			this.textBox13.Size = new System.Drawing.Size(24, 22);
			this.textBox13.TabIndex = 12;
			// 
			// textBox14
			// 
			this.textBox14.Location = new System.Drawing.Point(254, 65);
			this.textBox14.Name = "textBox14";
			this.textBox14.Size = new System.Drawing.Size(24, 22);
			this.textBox14.TabIndex = 13;
			// 
			// textBox15
			// 
			this.textBox15.Location = new System.Drawing.Point(74, 93);
			this.textBox15.Name = "textBox15";
			this.textBox15.Size = new System.Drawing.Size(24, 22);
			this.textBox15.TabIndex = 14;
			// 
			// textBox16
			// 
			this.textBox16.Location = new System.Drawing.Point(104, 93);
			this.textBox16.Name = "textBox16";
			this.textBox16.Size = new System.Drawing.Size(24, 22);
			this.textBox16.TabIndex = 15;
			// 
			// textBox17
			// 
			this.textBox17.Location = new System.Drawing.Point(134, 93);
			this.textBox17.Name = "textBox17";
			this.textBox17.Size = new System.Drawing.Size(24, 22);
			this.textBox17.TabIndex = 16;
			// 
			// textBox18
			// 
			this.textBox18.Location = new System.Drawing.Point(164, 93);
			this.textBox18.Name = "textBox18";
			this.textBox18.Size = new System.Drawing.Size(24, 22);
			this.textBox18.TabIndex = 17;
			// 
			// textBox19
			// 
			this.textBox19.Location = new System.Drawing.Point(194, 93);
			this.textBox19.Name = "textBox19";
			this.textBox19.Size = new System.Drawing.Size(24, 22);
			this.textBox19.TabIndex = 18;
			// 
			// textBox20
			// 
			this.textBox20.Location = new System.Drawing.Point(224, 93);
			this.textBox20.Name = "textBox20";
			this.textBox20.Size = new System.Drawing.Size(24, 22);
			this.textBox20.TabIndex = 19;
			// 
			// textBox21
			// 
			this.textBox21.Location = new System.Drawing.Point(254, 93);
			this.textBox21.Name = "textBox21";
			this.textBox21.Size = new System.Drawing.Size(24, 22);
			this.textBox21.TabIndex = 20;
			// 
			// textBox22
			// 
			this.textBox22.Location = new System.Drawing.Point(74, 121);
			this.textBox22.Name = "textBox22";
			this.textBox22.Size = new System.Drawing.Size(24, 22);
			this.textBox22.TabIndex = 21;
			// 
			// textBox23
			// 
			this.textBox23.Location = new System.Drawing.Point(104, 121);
			this.textBox23.Name = "textBox23";
			this.textBox23.Size = new System.Drawing.Size(24, 22);
			this.textBox23.TabIndex = 22;
			// 
			// textBox24
			// 
			this.textBox24.Location = new System.Drawing.Point(134, 121);
			this.textBox24.Name = "textBox24";
			this.textBox24.Size = new System.Drawing.Size(24, 22);
			this.textBox24.TabIndex = 23;
			// 
			// textBox25
			// 
			this.textBox25.Location = new System.Drawing.Point(164, 121);
			this.textBox25.Name = "textBox25";
			this.textBox25.Size = new System.Drawing.Size(24, 22);
			this.textBox25.TabIndex = 24;
			// 
			// textBox26
			// 
			this.textBox26.Location = new System.Drawing.Point(194, 121);
			this.textBox26.Name = "textBox26";
			this.textBox26.Size = new System.Drawing.Size(24, 22);
			this.textBox26.TabIndex = 25;
			// 
			// textBox27
			// 
			this.textBox27.Location = new System.Drawing.Point(224, 121);
			this.textBox27.Name = "textBox27";
			this.textBox27.Size = new System.Drawing.Size(24, 22);
			this.textBox27.TabIndex = 26;
			// 
			// textBox28
			// 
			this.textBox28.Location = new System.Drawing.Point(254, 121);
			this.textBox28.Name = "textBox28";
			this.textBox28.Size = new System.Drawing.Size(24, 22);
			this.textBox28.TabIndex = 27;
			// 
			// textBox29
			// 
			this.textBox29.Location = new System.Drawing.Point(74, 149);
			this.textBox29.Name = "textBox29";
			this.textBox29.Size = new System.Drawing.Size(24, 22);
			this.textBox29.TabIndex = 28;
			// 
			// textBox30
			// 
			this.textBox30.Location = new System.Drawing.Point(104, 149);
			this.textBox30.Name = "textBox30";
			this.textBox30.Size = new System.Drawing.Size(24, 22);
			this.textBox30.TabIndex = 29;
			// 
			// textBox31
			// 
			this.textBox31.Location = new System.Drawing.Point(134, 149);
			this.textBox31.Name = "textBox31";
			this.textBox31.Size = new System.Drawing.Size(24, 22);
			this.textBox31.TabIndex = 30;
			// 
			// textBox32
			// 
			this.textBox32.Location = new System.Drawing.Point(164, 149);
			this.textBox32.Name = "textBox32";
			this.textBox32.Size = new System.Drawing.Size(24, 22);
			this.textBox32.TabIndex = 31;
			// 
			// textBox33
			// 
			this.textBox33.Location = new System.Drawing.Point(194, 149);
			this.textBox33.Name = "textBox33";
			this.textBox33.Size = new System.Drawing.Size(24, 22);
			this.textBox33.TabIndex = 32;
			// 
			// textBox34
			// 
			this.textBox34.Location = new System.Drawing.Point(224, 149);
			this.textBox34.Name = "textBox34";
			this.textBox34.Size = new System.Drawing.Size(24, 22);
			this.textBox34.TabIndex = 33;
			// 
			// textBox35
			// 
			this.textBox35.Location = new System.Drawing.Point(254, 149);
			this.textBox35.Name = "textBox35";
			this.textBox35.Size = new System.Drawing.Size(24, 22);
			this.textBox35.TabIndex = 34;
			// 
			// textBox36
			// 
			this.textBox36.Location = new System.Drawing.Point(74, 177);
			this.textBox36.Name = "textBox36";
			this.textBox36.Size = new System.Drawing.Size(24, 22);
			this.textBox36.TabIndex = 35;
			// 
			// textBox37
			// 
			this.textBox37.Location = new System.Drawing.Point(104, 177);
			this.textBox37.Name = "textBox37";
			this.textBox37.Size = new System.Drawing.Size(24, 22);
			this.textBox37.TabIndex = 36;
			// 
			// textBox38
			// 
			this.textBox38.Location = new System.Drawing.Point(134, 177);
			this.textBox38.Name = "textBox38";
			this.textBox38.Size = new System.Drawing.Size(24, 22);
			this.textBox38.TabIndex = 37;
			// 
			// textBox39
			// 
			this.textBox39.Location = new System.Drawing.Point(164, 177);
			this.textBox39.Name = "textBox39";
			this.textBox39.Size = new System.Drawing.Size(24, 22);
			this.textBox39.TabIndex = 38;
			// 
			// textBox40
			// 
			this.textBox40.Location = new System.Drawing.Point(194, 177);
			this.textBox40.Name = "textBox40";
			this.textBox40.Size = new System.Drawing.Size(24, 22);
			this.textBox40.TabIndex = 39;
			// 
			// textBox41
			// 
			this.textBox41.Location = new System.Drawing.Point(224, 177);
			this.textBox41.Name = "textBox41";
			this.textBox41.Size = new System.Drawing.Size(24, 22);
			this.textBox41.TabIndex = 40;
			// 
			// textBox42
			// 
			this.textBox42.Location = new System.Drawing.Point(254, 177);
			this.textBox42.Name = "textBox42";
			this.textBox42.Size = new System.Drawing.Size(24, 22);
			this.textBox42.TabIndex = 41;
			// 
			// textBox43
			// 
			this.textBox43.Location = new System.Drawing.Point(74, 205);
			this.textBox43.Name = "textBox43";
			this.textBox43.Size = new System.Drawing.Size(24, 22);
			this.textBox43.TabIndex = 42;
			// 
			// textBox44
			// 
			this.textBox44.Location = new System.Drawing.Point(104, 205);
			this.textBox44.Name = "textBox44";
			this.textBox44.Size = new System.Drawing.Size(24, 22);
			this.textBox44.TabIndex = 43;
			// 
			// textBox45
			// 
			this.textBox45.Location = new System.Drawing.Point(134, 205);
			this.textBox45.Name = "textBox45";
			this.textBox45.Size = new System.Drawing.Size(24, 22);
			this.textBox45.TabIndex = 44;
			// 
			// textBox46
			// 
			this.textBox46.Location = new System.Drawing.Point(164, 205);
			this.textBox46.Name = "textBox46";
			this.textBox46.Size = new System.Drawing.Size(24, 22);
			this.textBox46.TabIndex = 45;
			// 
			// textBox47
			// 
			this.textBox47.Location = new System.Drawing.Point(194, 205);
			this.textBox47.Name = "textBox47";
			this.textBox47.Size = new System.Drawing.Size(24, 22);
			this.textBox47.TabIndex = 46;
			// 
			// textBox48
			// 
			this.textBox48.Location = new System.Drawing.Point(224, 205);
			this.textBox48.Name = "textBox48";
			this.textBox48.Size = new System.Drawing.Size(24, 22);
			this.textBox48.TabIndex = 47;
			// 
			// textBox49
			// 
			this.textBox49.Location = new System.Drawing.Point(254, 205);
			this.textBox49.Name = "textBox49";
			this.textBox49.Size = new System.Drawing.Size(24, 22);
			this.textBox49.TabIndex = 48;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(25, 47);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(29, 12);
			this.label1.TabIndex = 49;
			this.label1.Text = "入口";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(296, 214);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(29, 12);
			this.label2.TabIndex = 50;
			this.label2.Text = "出口";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(60, 265);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 51;
			this.button1.Text = "儲存檔案";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(143, 265);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 23);
			this.button2.TabIndex = 52;
			this.button2.Text = "讀檔輸入";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(224, 265);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(75, 23);
			this.button3.TabIndex = 53;
			this.button3.Text = "走出迷宮";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(386, 315);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.textBox49);
			this.Controls.Add(this.textBox48);
			this.Controls.Add(this.textBox47);
			this.Controls.Add(this.textBox46);
			this.Controls.Add(this.textBox45);
			this.Controls.Add(this.textBox44);
			this.Controls.Add(this.textBox43);
			this.Controls.Add(this.textBox42);
			this.Controls.Add(this.textBox41);
			this.Controls.Add(this.textBox40);
			this.Controls.Add(this.textBox39);
			this.Controls.Add(this.textBox38);
			this.Controls.Add(this.textBox37);
			this.Controls.Add(this.textBox36);
			this.Controls.Add(this.textBox35);
			this.Controls.Add(this.textBox34);
			this.Controls.Add(this.textBox33);
			this.Controls.Add(this.textBox32);
			this.Controls.Add(this.textBox31);
			this.Controls.Add(this.textBox30);
			this.Controls.Add(this.textBox29);
			this.Controls.Add(this.textBox28);
			this.Controls.Add(this.textBox27);
			this.Controls.Add(this.textBox26);
			this.Controls.Add(this.textBox25);
			this.Controls.Add(this.textBox24);
			this.Controls.Add(this.textBox23);
			this.Controls.Add(this.textBox22);
			this.Controls.Add(this.textBox21);
			this.Controls.Add(this.textBox20);
			this.Controls.Add(this.textBox19);
			this.Controls.Add(this.textBox18);
			this.Controls.Add(this.textBox17);
			this.Controls.Add(this.textBox16);
			this.Controls.Add(this.textBox15);
			this.Controls.Add(this.textBox14);
			this.Controls.Add(this.textBox13);
			this.Controls.Add(this.textBox12);
			this.Controls.Add(this.textBox11);
			this.Controls.Add(this.textBox10);
			this.Controls.Add(this.textBox9);
			this.Controls.Add(this.textBox8);
			this.Controls.Add(this.textBox7);
			this.Controls.Add(this.textBox6);
			this.Controls.Add(this.textBox5);
			this.Controls.Add(this.textBox4);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Name = "Form1";
			this.Text = "走迷宮";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.TextBox textBox7;
		private System.Windows.Forms.TextBox textBox8;
		private System.Windows.Forms.TextBox textBox9;
		private System.Windows.Forms.TextBox textBox10;
		private System.Windows.Forms.TextBox textBox11;
		private System.Windows.Forms.TextBox textBox12;
		private System.Windows.Forms.TextBox textBox13;
		private System.Windows.Forms.TextBox textBox14;
		private System.Windows.Forms.TextBox textBox15;
		private System.Windows.Forms.TextBox textBox16;
		private System.Windows.Forms.TextBox textBox17;
		private System.Windows.Forms.TextBox textBox18;
		private System.Windows.Forms.TextBox textBox19;
		private System.Windows.Forms.TextBox textBox20;
		private System.Windows.Forms.TextBox textBox21;
		private System.Windows.Forms.TextBox textBox22;
		private System.Windows.Forms.TextBox textBox23;
		private System.Windows.Forms.TextBox textBox24;
		private System.Windows.Forms.TextBox textBox25;
		private System.Windows.Forms.TextBox textBox26;
		private System.Windows.Forms.TextBox textBox27;
		private System.Windows.Forms.TextBox textBox28;
		private System.Windows.Forms.TextBox textBox29;
		private System.Windows.Forms.TextBox textBox30;
		private System.Windows.Forms.TextBox textBox31;
		private System.Windows.Forms.TextBox textBox32;
		private System.Windows.Forms.TextBox textBox33;
		private System.Windows.Forms.TextBox textBox34;
		private System.Windows.Forms.TextBox textBox35;
		private System.Windows.Forms.TextBox textBox36;
		private System.Windows.Forms.TextBox textBox37;
		private System.Windows.Forms.TextBox textBox38;
		private System.Windows.Forms.TextBox textBox39;
		private System.Windows.Forms.TextBox textBox40;
		private System.Windows.Forms.TextBox textBox41;
		private System.Windows.Forms.TextBox textBox42;
		private System.Windows.Forms.TextBox textBox43;
		private System.Windows.Forms.TextBox textBox44;
		private System.Windows.Forms.TextBox textBox45;
		private System.Windows.Forms.TextBox textBox46;
		private System.Windows.Forms.TextBox textBox47;
		private System.Windows.Forms.TextBox textBox48;
		private System.Windows.Forms.TextBox textBox49;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
	}
}

