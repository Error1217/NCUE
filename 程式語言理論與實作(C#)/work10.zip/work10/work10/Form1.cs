﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace work10
{
    public partial class Form1 : Form
    {
        class node
        {
            int? data;
            node left;
            node right;
            public node(int? data)
            {
                this.data = data;
                this.left = null;
                this.right = null;
            }
            public int? getData()
            {
                return this.data;
            }
            public node getLeft()
            {
                return this.left;
            }
            public node getRight()
            {
                return this.right;
            }
            public void setData(int? data)
            {
                this.data = data;
            }
            public void setLeft(node n)
            {
                this.left = n;
            }
            public void setRight(node n)
            {
                this.right = n;
            }
        }
        void inorder(node ptr)
        {
            if (ptr != null)
            {
                inorder(ptr.getLeft());
                if (ptr.getData() != null)
                {
                    textBox2.Text += ptr.getData() + " ";
                }
                inorder(ptr.getRight());
            }
        }
        void preorder(node ptr)
        {
            if (ptr != null)
            {
                if (ptr.getData() != null)
                {
                    textBox2.Text += ptr.getData() + " ";
                }
                preorder(ptr.getLeft());
                preorder(ptr.getRight());
            }
        }
        void postorder(node ptr)
        {
            if (ptr != null)
            {
                postorder(ptr.getLeft());
                postorder(ptr.getRight());
                if (ptr.getData() != null)
                {
                    textBox2.Text += ptr.getData() + " ";
                }
                    
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox2.ReadOnly = true;
        }

        node root = new node(null);
        private void button1_Click(object sender, EventArgs e)
        {
            node ptr1 = root;
            node ptr2 = root.getLeft();
            int? data = Convert.ToInt32(textBox1.Text);
            node x = new node(data);
            if (ptr2 == null)
            {
                root.setLeft(x);
            }
            while(ptr2 != null)
            {
                if (ptr2.getData() == data)
                {
                    MessageBox.Show("資料" + data + "已存在", "新增失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                ptr1 = ptr2;
                if (data < ptr2.getData())
                {
                    ptr2 = ptr2.getLeft();
                }
                else
                {
                    ptr2 = ptr2.getRight();
                }
            }
            if (data < ptr1.getData())
            {
                ptr1.setLeft(x);
                textBox2.Text += x.getData() + " ";
            }
            else
            {
                ptr1.setRight(x);
                textBox2.Text += x.getData() + " ";
            }
            textBox1.Text = "";
            textBox2.Text = "";
            inorder(root.getLeft());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            preorder(root.getLeft());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            inorder(root.getLeft());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            postorder(root.getLeft());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            node ptr1 = root;
            node ptr2 = root.getLeft();
            int? data = Convert.ToInt32(textBox1.Text);
            string tmp = "L";
            while(ptr2 != null)
            {
                if(ptr2.getData()== data)
                {
                    break;
                }
                ptr1 = ptr2;
                if (data < ptr2.getData())
                {
                    ptr2 = ptr2.getLeft();
                    tmp = "L";
                }
                else
                {
                    ptr2 = ptr2.getRight();
                    tmp = "R";
                }
            }
            if (ptr2 == null)
            {
                MessageBox.Show("資料" + data + "不存在", "刪除失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (ptr2.getLeft() == null && ptr2.getRight() == null)
                {
                    if (tmp == "R")
                        ptr1.setRight(null);
                    if (tmp == "L")
                        ptr1.setLeft(null);
                }
                else if (ptr2.getRight() != null && ptr2.getLeft() == null)
                {
                    if (tmp == "R")
                        ptr1.setRight(ptr2.getRight());
                    if (tmp == "L")
                        ptr1.setLeft(ptr2.getRight());
                }
                else if (ptr2.getLeft()!=null && ptr2.getRight() == null)
                {
                    if (tmp == "R")
                        ptr1.setRight(ptr2.getLeft());
                    if (tmp == "L")
                        ptr1.setLeft(ptr2.getLeft());
                }
                else
                {
                    node ptr3 = ptr2;
                    node ptr4 = ptr2.getLeft();
                    while (ptr4.getRight() != null)
                    {
                        ptr3 = ptr4;
                        ptr4 = ptr4.getRight();
                    }
                    ptr2.setData(ptr4.getData());
                    if (ptr2.getData() == ptr3.getData())
                    {
                        ptr3.setLeft(ptr4.getLeft());
                    }
                    else if (ptr4.getLeft() != null)
                    {
                        ptr3.setRight(ptr4.getLeft());
                    }
                    else
                    {
                        ptr3.setRight(null);
                    }
                }
            }
            textBox2.Text = "";
            inorder(root.getLeft());
        }
    }
}
