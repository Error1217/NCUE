﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace work09
{
    public partial class Form1 : Form
    {
        class node
        {
            int ?data;
            node next;
            public node(int? n)
            {
                data = n;
                next = null;
            }
            public int? getData()
            {
                return data;
            }
            public node getNext()
            {
                return next;
            }
            public void setData(int n)
            {
                data = n;
            }
            public void setNext(node d)
            {
                next = d;
            }


        }
       

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox2.Text = "head->null";
            textBox2.ReadOnly = true;
        }

        node head = new node(null);
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                node ptr1 = head;
                node ptr2 = head.getNext();
                int? data = Convert.ToInt32(textBox1.Text);
                node x = new node(data);
                while (ptr2 != null)
                {
                    if (ptr2.getData() > data)
                    {
                        ptr1.setNext(x);
                        x.setNext(ptr2);
                        break;
                    }
                    if (ptr2.getData() == data)
                    {
                        throw new Exception("資料" + data + "重複");
                    }
                        ptr1 = ptr2;
                    ptr2 = ptr2.getNext();
                }
                ptr1.setNext(x);

                node ptr3 = head.getNext();
                textBox2.Text = "head->";
                while (ptr3 != null)
                {
                    textBox2.Text += ptr3.getData() + "->";
                    ptr3 = ptr3.getNext();
                }
                textBox2.Text += "null";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "錯誤訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int data = Convert.ToInt32(textBox1.Text);
            node ptr1 = head;
            node ptr2 = head.getNext();
            while(ptr2 != null)
            {
                if (ptr2.getData() == data)
                {
                    ptr1.setNext(ptr2.getNext());
                    break;
                }
                if (ptr2.getData() > data)
                {
                    MessageBox.Show("串列中沒有" + data, "無法刪除", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                }
                ptr1 = ptr2;
                ptr2 = ptr2.getNext();
            }
            if (ptr2 == null)
            {
                MessageBox.Show("串列中沒有" + data, "無法刪除", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            node ptr3 = head.getNext();
            textBox2.Text = "head->";
            while (ptr3 != null)
            {
                textBox2.Text += ptr3.getData() + "->";
                ptr3 = ptr3.getNext();
            }
            textBox2.Text += "null";
        }
    }
}
