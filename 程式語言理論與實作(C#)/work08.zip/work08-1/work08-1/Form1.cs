﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace work08_1
{
    public partial class Form1 : Form
    {
        TextBox[] box = new TextBox[8];
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            box[0] = textBox1;
            box[1] = textBox2;
            box[2] = textBox3;
            box[3] = textBox4;
            box[4] = textBox5;
            box[5] = textBox6;
            box[6] = textBox7;
            box[7] = textBox8;
            textBox11.Text = ""+7;
            textBox12.Text = "" + 7;
        }
        class CircularQueue
        {
            int[] queue = new int[8];
            public int rear = 7, front = 7;
            public void enqueue(int item)
            {
                if (front == (rear + 1) % 8)
                {
                    MessageBox.Show("空間已滿", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    rear = (rear + 1) % 8;
                    queue[rear] = item;
                }
            }
            public int dequeue()
            {
                if (rear == front)
                {
                    MessageBox.Show("沒有資料", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 0;
                }
                else
                {
                    front = (front + 1) % 8;
                    return queue[front];
                }
            }
        }
        CircularQueue q = new CircularQueue();
        private void button1_Click(object sender, EventArgs e)
        {
            
            q.enqueue(Convert.ToInt32(textBox9.Text));
            box[q.rear].Text = textBox9.Text;
            textBox12.Text =  ""+q.rear;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox10.Text = ""+ q.dequeue();
            box[q.front].Text = "";
            textBox11.Text = "" + q.front;
        }
    }
}

