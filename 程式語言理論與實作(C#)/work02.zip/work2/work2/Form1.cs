﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace work2
{
    public partial class Form1 : Form
    {
        double n1 = 0, n2 = 0, a = 0;
        char op = ' ';
        bool num = true;
        bool point = false;
        bool pre = false;
        bool equ = false;

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            n1 = 0; n2 = 0;
            op = ' ';
            num = true;
            point = false;
            pre = false;
            equ = false;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (num == true || textBox1.Text == "0")
                textBox1.Text = "1";
            else
                textBox1.Text += "1";
            num = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (num == true || textBox1.Text == "0")
                textBox1.Text = "2";
            else
                textBox1.Text += "2";
            num = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (num == true || textBox1.Text == "0")
                textBox1.Text = "3";
            else
                textBox1.Text += "3";
            num = false;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (num == true || textBox1.Text == "0")
                textBox1.Text = "4";
            else
                textBox1.Text += "4";
            num = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (num == true || textBox1.Text == "0")
                textBox1.Text = "5";
            else
                textBox1.Text += "5";
            num = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (num == true || textBox1.Text == "0")
                textBox1.Text = "6";
            else
                textBox1.Text += "6";
            num = false;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (num == true || textBox1.Text == "0")
                textBox1.Text = "7";
            else
                textBox1.Text += "7";
            num = false;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (num == true || textBox1.Text == "0")
                textBox1.Text = "8";
            else
                textBox1.Text += "8";
            num = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (num == true || textBox1.Text == "0")
                textBox1.Text = "9";
            else
                textBox1.Text += "9";
            num = false;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (num == true || textBox1.Text == "0")
                textBox1.Text = "0";
            else
                textBox1.Text += "0";
            num = false;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (num == true)
                textBox1.Text = "0.";
            else if (point == false)
                textBox1.Text += ".";
            point = true;
            num = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            num = true;
            point = false;
            equ = false;
            if (pre == false)
            {
                n1 = Convert.ToDouble(textBox1.Text);
                pre = true;
            }
            else
            {
                n2 = Convert.ToDouble(textBox1.Text);
                if (op == '+')
                    n1 = n1 + n2;
                else if (op == '-')
                    n1 = n1 - n2;
                else if (op == '*')
                    n1 = n1 * n2;
                else if (op == '/')
                    n1 = n1 / n2;
            }
            op = '+';
        }

        private void button3_Click(object sender, EventArgs e)
        {
            num = true;
            point = false;
            equ = false;
            if (pre == false)
            {
                n1 = Convert.ToDouble(textBox1.Text);
                pre = true;
            }
            else
            {
                n2 = Convert.ToDouble(textBox1.Text);
                if (op == '+')
                    n1 = n1 + n2;
                else if (op == '-')
                    n1 = n1 - n2;
                else if (op == '*')
                    n1 = n1 * n2;
                else if (op == '/')
                    n1 = n1 / n2;
            }

            op = '-';
        }

        private void button4_Click(object sender, EventArgs e)
        {
            num = true;
            point = false;
            equ = false;
            if (pre == false)
            {
                n1 = Convert.ToDouble(textBox1.Text);
                pre = true;
            }
            else
            {
                n2 = Convert.ToDouble(textBox1.Text);
                if (op == '+')
                    n1 = n1 + n2;
                else if (op == '-')
                    n1 = n1 - n2;
                else if (op == '*')
                    n1 = n1 * n2;
                else if (op == '/')
                    n1 = n1 / n2;
            }

            op = '*';
        }

        private void button17_Click(object sender, EventArgs e)
        {
            num = true;
            point = false;
            equ = false;
            if (pre == false)
            {
                n1 = Convert.ToDouble(textBox1.Text);
                pre = true;
            }
            else
            {
                n2 = Convert.ToDouble(textBox1.Text);
                if (op == '+')
                    n1 = n1 + n2;
                else if (op == '-')
                    n1 = n1 - n2;
                else if (op == '*')
                    n1 = n1 * n2;
                else if (op == '/')
                    n1 = n1 / n2;
            }
            op = '/';
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (equ == false)
            {
                n2 = Convert.ToDouble(textBox1.Text);
                pre = false;
                equ = true;
                a = n2;
                if (op == '+')
                    n1 = n1 + n2;
                else if (op == '-')
                    n1 = n1 - n2;
                else if (op == '*')
                    n1 = n1 * n2;
                else if (op == '/')
                    n1 = n1 / n2;
            }
            else
            {
                n2 = Convert.ToDouble(textBox1.Text);
                if (op == '+')
                    n1 = n1 + a;
                else if (op == '-')
                    n1 = n1 - a;
                else if (op == '*')
                    n1 = n1 * a;
                else if (op == '/')
                    n1 = n1 / a;
            }
            textBox1.Text = "" + n1;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.ReadOnly = true;
        }
    }
}
